
  # Multi-page Farming Awareness Website

  This is a code bundle for Multi-page Farming Awareness Website. The original project is available at https://www.figma.com/design/AvW91rBUCDXLDID4vqQ00T/Multi-page-Farming-Awareness-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  